package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.CandidateDaoImpl;
import Dao.VotingDaoImpl;
import Pojo.Voter;


@WebServlet(urlPatterns="/login",loadOnStartup=1)
public class LoginServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
      private VotingDaoImpl dao;
      private CandidateDaoImpl cdao;
   
	
    public LoginServlet()
    {
        super();
        
    }

    @Override
    public void init() throws ServletException 
    {
    	try 
    	{
    		System.out.println("in init");
			dao=new VotingDaoImpl();
		} 
    	catch (Exception e) 
    	{
    		throw new ServletException("problem with init"+getClass().getName()+e);
		}
    	
    }
	
    public void destroy() 
    {
		if (dao != null)
			try 
			{
				dao.cleanUp();
			} 
			catch (Exception e) 
			{
				throw new RuntimeException("err in destory", e);
			}
	}
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		response.setContentType("text/html");
		try(PrintWriter pw=response.getWriter())
		{
			String email=request.getParameter("em");
			String password=request.getParameter("pass");
			
			Voter c = dao.authenticateVoter(email,password);
			
			
			String voted=c.getStatus();
			String role=c.getRole();
			System.out.println(role);
			
			if(c.getRole().equals("admin"))
			{

				HttpSession hs=request.getSession();
				hs.setAttribute("voter_detail",c);
				hs.setAttribute("voter_dao", dao);

				response.sendRedirect("admin");
			}
			else if(voted.equals("false"))
			{
				if (c == null)
					pw.print("<h4> Invalid Login , Pls <a href=login.html>Retry</a></h4>");
				else
				{
//					Cookie c1=new Cookie("cust_details", c.toString());
//					response.addCookie(c1);
//					response.sendRedirect("details");
					
					HttpSession hs=request.getSession();
					hs.setAttribute("voter_detail",c);
					
					hs.setAttribute("voter_dao", dao);
					hs.setAttribute("candidate_dao", cdao);
					
					response.sendRedirect("list");
					
				}
			}
			else 
				response.sendRedirect("test");
			
			
		}
		catch (Exception e)
		{
			throw new ServletException("problem with doPost"+getClass().getName()+e);
		}

	}
}