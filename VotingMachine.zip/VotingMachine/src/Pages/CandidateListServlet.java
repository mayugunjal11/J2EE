package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.VotingDaoImpl;
import Pojo.Candidate;
import Pojo.Voter;


@WebServlet("/list")
public class CandidateListServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
       //private VotingDaoImpl dao;
    
    


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		try(PrintWriter pw=response.getWriter())
		{
			pw.print("welcome to candiadte list");
			
			HttpSession hs = request.getSession();
			
			Voter c=(Voter)hs.getAttribute("voter_detail");
			VotingDaoImpl dao=(VotingDaoImpl) hs.getAttribute("voter_dao");
			
			
			if(c!=null)
			{
				List<Candidate> candidates=dao.getCandidateList();
				
				pw.print("<form action=status>");
				for(Candidate c1  : candidates)
					 pw.print("<input type=radio name=c_id value="+c1.getName()+">"+c1.getName());
				pw.print("<input type=submit value='Vote'>");
				pw.print("</form>");
			}
			else
				pw.print("<h5>Session tracking failed : no cookies</h5>");
			

		}
		catch (Exception e)
		{
				throw new ServletException("err in do-get of " + getClass().getName(), e);
		}
		
	}

}
