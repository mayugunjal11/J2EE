package Utils;

import java.sql.*;

public class DBUtils {
	private static Connection cn;

	private DBUtils() throws Exception {
		// load drvr class
		Class.forName("com.mysql.cj.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/J2EE";
		cn = DriverManager.getConnection(dbURL, "root", "manager");
	}

	public static Connection getConnection() throws Exception {
		if (cn == null) {
			DBUtils utils = new DBUtils();
		}
		return cn;

	}
}